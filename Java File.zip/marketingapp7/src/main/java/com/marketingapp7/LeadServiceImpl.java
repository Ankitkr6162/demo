package com.marketingapp7;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marketingapp7.Repository.LeadRepository;
import com.marketingapp7.entity.Lead;
import com.marketingapp7.service.LeadService;
import com.marketingapp7.service.List;

@Service
public class LeadServiceImpl implements LeadService {

	@Autowired
private LeadRepository leadRepo;
	
	
	
	
	@Override
	public void saveLead(Lead lead) {
	
	leadRepo.save(lead);

	}



	@Override
	public java.util.List<Lead> getAllLead() {
		   
	java.util.List<Lead> lead = leadRepo.findAll();	
		return lead;
	}


//delete jsp
	@Override
	public void deletLeadbyId(long id) {
	leadRepo.deleteById(id);
		
	}

//update jsp

	@Override
	public Lead findLeadById(long id) {
		Optional<Lead> findById = leadRepo.findById(id);
		
		return findById.get();
	}

}
