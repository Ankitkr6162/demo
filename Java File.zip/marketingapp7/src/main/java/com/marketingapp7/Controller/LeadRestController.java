package com.marketingapp7.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.marketingapp7.Repository.LeadRepository;
import com.marketingapp7.dto.LeadDto;
import com.marketingapp7.entity.Lead;

@RestController
@RequestMapping("/api/leads")
public class LeadRestController {

@Autowired	
private LeadRepository leadRepo;	
	
//http://localhost8080/api/leads

@GetMapping
public 	List<Lead> getAllLead( ){
	List<Lead> leads =	leadRepo.findAll();
	return leads;
	
	
	
}
@PostMapping
public void CreateLead(@RequestBody Lead lead) {
	leadRepo.save(lead);
	
}
//deleted concepts
//h://localhost:8080/api/leads/1ttp
@DeleteMapping("/{id}")
public void deleteLead(@PathVariable("id") long id) {

	leadRepo.deleteById(id);
}

//update
//http://localhost:8080/api/leads/1
@PutMapping("/{id}")
public void updateLead(@RequestBody LeadDto dto, @PathVariable("id") long id) {
	
Lead l = new Lead();
	l.setId(id);
	l.setFirstName(dto.getFirstName());
	l.setLastName(dto.getLastName());
	l.setEmail(dto.getEmail());
	l.setMobile(dto.getMobile());
	
	leadRepo.save(l);
	
}
	
}
